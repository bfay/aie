<?php
/*
* Plugin Name: WOO Product Page for Visual Composer
* Plugin URI: http://getextension.net/
* Description: WOO single product page builder for Visual Composer
* Version: 1.2.3
* Author: DHZoanku
* Author URI: http://getextension.net/
* License: License GNU General Public License version 2 or later;
* Copyright 2013  DH Zoanku
*/

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

if(!defined('DHVC_WOO_PAGE'))
	define('DHVC_WOO_PAGE','dhvc-woo-page-builder');

if(!defined('DHVC_WOO_PAGE_VERSION'))
	define('DHVC_WOO_PAGE_VERSION','1.2.3');

if(!defined('DHVC_WOO_PAGE_URL'))
	define('DHVC_WOO_PAGE_URL',untrailingslashit( plugins_url( '/', __FILE__ ) ));

if(!defined('DHVC_WOO_PAGE_DIR'))
	define('DHVC_WOO_PAGE_DIR',untrailingslashit( plugin_dir_path( __FILE__ ) ));

if (!function_exists('dhwc_is_active')){
	/**
	 * Check woocommerce plugin is active
	 *
	 * @return boolean .TRUE is active
	 */
	function dhwc_is_active(){
		$active_plugins = (array) get_option( 'active_plugins', array() );

		if ( is_multisite() )
			$active_plugins = array_merge($active_plugins, get_site_option( 'active_sitewide_plugins', array() ) );

		return in_array( 'woocommerce/woocommerce.php', $active_plugins ) || array_key_exists( 'woocommerce/woocommerce.php', $active_plugins );
	}
}

if(!class_exists('DHVC_Woo_Page')):


global $product_page;

class DHVC_Woo_Page{
	
	public function __construct(){
		add_action('init',array(&$this,'init'));
		
	}
	
	public function init(){
		load_plugin_textdomain( DHVC_WOO_PAGE, false, dirname( plugin_basename( __FILE__ ) ) . '/languages' );
		wp_register_style('dhvc-woo-page-chosen', DHVC_WOO_PAGE_URL.'/assets/css/chosen.min.css');
		
		if ( ! defined( 'WPB_VC_VERSION' ) ) {
			add_action('admin_notices', array(&$this,'notice'));
			return;
		}
		if(!dhwc_is_active()){
			add_action('admin_notices', array(&$this,'woocommerce_notice'));
			return;
		}
		

		require_once DHVC_WOO_PAGE_DIR.'/includes/shortcode.php';
		
		$params_script = DHVC_WOO_PAGE_URL.'/assets/js/params.js';
		add_shortcode_param ( 'dhvc_woo_product_page_field_categories', 'dhvc_woo_product_page_setting_field_categories',$params_script);
		add_shortcode_param ( 'dhvc_woo_product_page_field_products_ajax', 'dhvc_woo_product_page_setting_field_products_ajax');
		
		require_once DHVC_WOO_PAGE_DIR.'/includes/functions.php';
		require_once DHVC_WOO_PAGE_DIR.'/includes/map.php';
		
		if(is_admin()):
			require_once DHVC_WOO_PAGE_DIR.'/includes/admin.php';
		else:
			wp_register_style('dhvc-woocommerce-page', DHVC_WOO_PAGE_URL.'/assets/css/style.css',array(),DHVC_WOO_PAGE_VERSION);
			add_filter( 'template_include', array( &$this, 'template_loader' ) ,1000);
		endif;

	}
	
	public function notice(){
		$plugin = get_plugin_data(__FILE__);
		echo '
			  <div class="updated">
			    <p>' . sprintf(__('<strong>%s</strong> requires <strong><a href="http://bit.ly/1gKaeh5" target="_blank">Visual Composer</a></strong> plugin to be installed and activated on your site.', DHVC_WOO), $plugin['Name']) . '</p>
			  </div>';
	}
	
	public function woocommerce_notice(){
		$plugin = get_plugin_data(__FILE__);
		echo '
			  <div class="updated">
			    <p>' . sprintf(__('<strong>%s</strong> requires <strong><a href="http://www.woothemes.com/woocommerce/" target="_blank">WooCommerce</a></strong> plugin to be installed and activated on your site.', DHVC_WOO), $plugin['Name']) . '</p>
			  </div>';
	}
	
	public function get_plugin_url(){
		return DHVC_WOO_PAGE_URL;
	}
	
	public function get_plugin_dir(){
		return DHVC_WOO_PAGE_DIR;
	}
	
	public function template_loader($template){
		
		if ( is_single() && get_post_type() == 'product' ) {
			global $post,$product_page;
			
			if($product_template_id = get_post_meta($post->ID,'dhvc_woo_page_product'.$post->ID,true)):
			
				if(class_exists('NewVisualComposer'))
				 	NewVisualComposer::disableInline();
				
				wp_enqueue_style('dhvc-woocommerce-page');
			
				$file 	= 'single-product.php';
				$find[] = 'dhvc-woocommerce-page/' . $file;
				$product_page = get_post($product_template_id);
				$template       = locate_template( $find );
				$status_options = get_option( 'woocommerce_status_options', array() );
				if ( ! $template || ( ! empty( $status_options['template_debug_mode'] ) && current_user_can( 'manage_options' ) ) )
					$template = $this->get_plugin_dir() . '/templates/' . $file;
				
				return $template;
			endif;
			$terms = wp_get_post_terms( $post->ID, 'product_cat' );
			foreach ( $terms as $term ):
				 if($product_template_id = get_woocommerce_term_meta($term->term_id,'dhvc_woo_page_cat_product'.$term->term_id,true)):
				 	
				 	if(class_exists('NewVisualComposer'))
				 		NewVisualComposer::disableInline();
					
				 	wp_enqueue_style('dhvc-woocommerce-page');
					
			
					$file 	= 'single-product.php';
					$find[] = 'dhvc-woocommerce-page/' . $file;
					$product_page = get_post($product_template_id);
					$template       = locate_template( $find );
					$status_options = get_option( 'woocommerce_status_options', array() );
					if ( ! $template || ( ! empty( $status_options['template_debug_mode'] ) && current_user_can( 'manage_options' ) ) )
						$template = $this->get_plugin_dir() . '/templates/' . $file;
					
					return $template;
				endif;
			endforeach;
			
			
		}
		return $template;
		
	}
}

new DHVC_Woo_Page();

endif;